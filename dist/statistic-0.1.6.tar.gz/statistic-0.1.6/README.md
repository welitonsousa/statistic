# Statistic

Esta biblioteca foi desenvolvida com o intuito de unir um grande acerto de cálculos estatísticos

## Desenvolvedores:
- Darice da Rocha Sousa
- Weliton de Sousa Araujo

## cálculos inclusos até o presente momento
- Media
- Media ponderada
- Mediana
- Moda
- Desvio padrão
- Desvio médio
- Variância
- Covariância
- Amplitude
- Erro padrão
- Coeficiente de variação
- Coeficiente de correlação
- Soma dos quadrados dos desvios de dados

[Veja a documentação](https://welitonsousa.vercel.app/post?id=lib-statistic-59a2ce35-a7c9-4aa3-8f5e-a5d632b21d6e)
